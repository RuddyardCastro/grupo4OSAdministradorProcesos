/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Mishel Loeiza
 */
public class JFrame2 {

    public JFrame2(String uso_de_Disco_por_Proceso) {
    }
    
}
